import checksumdir 

hash = checksumdir.dirhash("source_code")
print("Directory Checksum:", hash) 